-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-06-2020 a las 23:51:03
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sorteo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `tipo_documento` varchar(5) NOT NULL,
  `num_documento` bigint(20) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`tipo_documento`, `num_documento`, `nombres`, `apellidos`, `fecha_nacimiento`) VALUES
('CC', 1090, 'Karen', 'Lugo', '2020-04-27'),
('CC', 1091, 'Mauricio', 'Herrera', '1960-09-11'),
('CC', 1092, 'Juan David', 'Gil', '2020-06-10'),
('CC', 1093, 'karol', 'Lugo', '2020-06-04'),
('CC', 1094, 'Luis', 'Lugo', '2020-06-02'),
('CC', 1095, 'Rosa', 'Mira', '2020-06-02'),
('CC', 1096, 'Miguel', 'More', '2020-06-03'),
('CC', 1097, 'Mami', 'Arrieta', '2020-06-01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona_premio`
--

CREATE TABLE `persona_premio` (
  `ced_persona` bigint(11) NOT NULL,
  `id_premio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `persona_premio`
--

INSERT INTO `persona_premio` (`ced_persona`, `id_premio`) VALUES
(1090, 1),
(1091, 1),
(1092, 1),
(1093, 1),
(1094, 2),
(1095, 3),
(1096, 3),
(1097, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `premio`
--

CREATE TABLE `premio` (
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `premio`
--

INSERT INTO `premio` (`codigo`, `descripcion`, `cantidad`) VALUES
(1, 'Balon negro ', 0),
(2, 'Balon Blanco', 0),
(3, 'Dulce Blanco', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `usuario`, `clave`) VALUES
(1, 'rex', '1234');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`num_documento`);

--
-- Indices de la tabla `persona_premio`
--
ALTER TABLE `persona_premio`
  ADD PRIMARY KEY (`ced_persona`,`id_premio`),
  ADD KEY `id_premio` (`id_premio`),
  ADD KEY `ced_persona` (`ced_persona`);

--
-- Indices de la tabla `premio`
--
ALTER TABLE `premio`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `premio`
--
ALTER TABLE `premio`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `persona_premio`
--
ALTER TABLE `persona_premio`
  ADD CONSTRAINT `persona_premio_ibfk_1` FOREIGN KEY (`id_premio`) REFERENCES `premio` (`codigo`),
  ADD CONSTRAINT `persona_premio_ibfk_2` FOREIGN KEY (`ced_persona`) REFERENCES `persona` (`num_documento`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
