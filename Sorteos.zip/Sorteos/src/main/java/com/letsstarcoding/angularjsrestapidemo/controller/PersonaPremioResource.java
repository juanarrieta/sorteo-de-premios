package com.letsstarcoding.angularjsrestapidemo.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.model.PersonaPremio;
import com.letsstarcoding.angularjsrestapidemo.model.PersonaPremioPK;
import com.letsstarcoding.angularjsrestapidemo.model.Premio;
import com.letsstarcoding.angularjsrestapidemo.service.PersonaPremioService;
import com.letsstarcoding.angularjsrestapidemo.service.PersonaService;
import com.letsstarcoding.angularjsrestapidemo.service.PremioService;

import dto.DetallePersonaPremio;

@RestController
@RequestMapping("/api")
public class PersonaPremioResource {

	private PersonaPremioService personaPremioService;
	
	private PersonaService personaService;
	
	private PremioService premioService;
	
	public PersonaPremioResource(PersonaPremioService personaPremioService, PersonaService personaService, PremioService premioService) {
		this.personaPremioService = personaPremioService;
		this.personaService = personaService;
		this.premioService = premioService;
	}
	
	@RequestMapping(value="persona-premio",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<DetallePersonaPremio> findAll(){
		List<PersonaPremio> pps = personaPremioService.findAll();
		List<DetallePersonaPremio> detalles = new ArrayList<DetallePersonaPremio>();
		for (PersonaPremio pp : pps) 
		{ 
			Persona persona = personaService.findOne(pp.getId().getCedPersona());
			Premio premio = premioService.findOne(pp.getId().getIdPremio());
			DetallePersonaPremio personaPremio = new DetallePersonaPremio(persona, premio);
			detalles.add(personaPremio);
		}
		
		return detalles;
	}
	
	@RequestMapping(value = "persona-premio", method = RequestMethod.POST)
    public ResponseEntity<Void> sortearPremios() {
		List<Persona> personas = personaService.getPersonaSinPremio();
		List<Premio> premios = premioService.getPremios();
		
		if(personas.size() > 0 && premios.size() > 0) {
			for (Persona persona : personas) 
			{ 
				 int num = (int) Math.random()*premios.size();
				 Premio premio = premios.get(num);
				 premio.setCantidad(premio.getCantidad()-1);
				 
				 PersonaPremio personaPremio = new PersonaPremio();
				 personaPremio.setId(new PersonaPremioPK());
				 personaPremio.getId().setCedPersona(persona.getNumDocumento());
				 personaPremio.getId().setIdPremio(premio.getCodigo());
				 
				 PersonaPremio result = personaPremioService.save(personaPremio);
				 
				 premioService.update(premio);
			}
		}
		
        return ResponseEntity.ok().build();
    }
}
