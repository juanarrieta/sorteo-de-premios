package com.letsstarcoding.angularjsrestapidemo.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.repository.PersonaRepository;
import com.letsstarcoding.angularjsrestapidemo.service.PersonaService;

@RestController
@RequestMapping("/api")
public class PersonaResource {

	private PersonaService personaService;
	
	public PersonaResource(PersonaService personaService) {
		this.personaService = personaService;
	}
	
	@RequestMapping(value="persona",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Persona> getPersonas(){
		return personaService.findAll();
	}
		
	@RequestMapping(value = "/persona/{numDocumento}", method = RequestMethod.POST)
    public ResponseEntity<Persona> guardar(@PathVariable("numDocumento") long numDocumento, @RequestBody Persona persona) {
		Persona regPersona = personaService.findOne(numDocumento);

        if (regPersona == null) {
        	try {
    			Persona result = personaService.save(persona);
    			return ResponseEntity.created(new URI("/api/persona/"+result.getNumDocumento())).body(result);
    		}catch(Exception e) {
    			return new ResponseEntity<Persona>(HttpStatus.CONFLICT);
    		}
        }

        regPersona.setApellidos(persona.getApellidos());
        regPersona.setFechaNacimiento(persona.getFechaNacimiento());
        regPersona.setNombres(persona.getNombres());
        regPersona.setNumDocumento(persona.getNumDocumento());
        regPersona.setTipoDocumento(persona.getTipoDocumento());
        
        personaService.update(regPersona);
        return new ResponseEntity<Persona>(regPersona, HttpStatus.OK);
    }
	
	@RequestMapping(value="/persona/{numDocumento}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	public boolean eliminarPersona(@PathVariable Long numDocumento){
		try {
			personaService.delete(numDocumento);
			return true;
		}
		catch(Exception e){
			return false;
		}
	}
}
