package com.letsstarcoding.angularjsrestapidemo.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.model.Premio;
import com.letsstarcoding.angularjsrestapidemo.model.Usuario;
import com.letsstarcoding.angularjsrestapidemo.repository.UsuarioRepository;
import com.letsstarcoding.angularjsrestapidemo.service.PremioService;
import com.letsstarcoding.angularjsrestapidemo.service.UsuarioService;

@RestController
@RequestMapping("/api")
public class PremioResource {

	private PremioService premioService;
	
	public PremioResource(PremioService premioService) {
		this.premioService = premioService;
	}
	
	@RequestMapping(value="premio",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Premio> getAllUsers(){
		return premioService.findAll();
	}
}
