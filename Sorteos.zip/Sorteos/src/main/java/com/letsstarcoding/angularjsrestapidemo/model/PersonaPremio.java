package com.letsstarcoding.angularjsrestapidemo.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="persona_premio")
@EntityListeners(AuditingEntityListener.class)
public class PersonaPremio {
	
	@EmbeddedId
	private PersonaPremioPK id;
	
	public PersonaPremio() {
	}

	public PersonaPremioPK getId() {
		return id;
	}

	public void setId(PersonaPremioPK id) {
		this.id = id;
	}
	
}
