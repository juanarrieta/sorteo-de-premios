package com.letsstarcoding.angularjsrestapidemo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Embeddable
public class PersonaPremioPK implements Serializable{
	@Column(name = "ced_persona")
	private Long cedPersona;
	
	@Column(name = "id_premio")
	private int idPremio;

	public Long getCedPersona() {
		return cedPersona;
	}

	
	public PersonaPremioPK() {
	}


	public void setCedPersona(Long cedPersona) {
		this.cedPersona = cedPersona;
	}

	public int getIdPremio() {
		return idPremio;
	}

	public void setIdPremio(int idPremio) {
		this.idPremio = idPremio;
	}

}
