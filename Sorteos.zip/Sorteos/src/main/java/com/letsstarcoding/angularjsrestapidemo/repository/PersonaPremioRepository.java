package com.letsstarcoding.angularjsrestapidemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.letsstarcoding.angularjsrestapidemo.model.PersonaPremio;

public interface PersonaPremioRepository extends JpaRepository<PersonaPremio,Integer>{
	
}
