package com.letsstarcoding.angularjsrestapidemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;

public interface PersonaRepository extends JpaRepository<Persona,Long>{
	
	@Query(value="SELECT * FROM persona WHERE num_documento NOT IN (SELECT ced_persona FROM persona_premio)", nativeQuery = true)
	List<Persona> getPersonaSinPremio();
}
