package com.letsstarcoding.angularjsrestapidemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.model.Premio;

public interface PremioRepository extends JpaRepository<Premio,Integer>{
	@Query(value="SELECT * FROM premio WHERE cantidad > 0", nativeQuery = true)
	List<Premio> getPremios();
}
