package com.letsstarcoding.angularjsrestapidemo.service;

import java.util.List;

import javax.persistence.EntityExistsException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.model.PersonaPremio;
import com.letsstarcoding.angularjsrestapidemo.model.Usuario;
import com.letsstarcoding.angularjsrestapidemo.repository.PersonaPremioRepository;
import com.letsstarcoding.angularjsrestapidemo.repository.UsuarioRepository;


@Service
public class PersonaPremioService {

	private PersonaPremioRepository personaPremioRepository;
	
	@Autowired
	public PersonaPremioService(PersonaPremioRepository personaPremioRepository) {
		this.personaPremioRepository = personaPremioRepository;
	}
	
	public List<PersonaPremio> findAll(){
		return personaPremioRepository.findAll();
	}
	
	public PersonaPremio save(PersonaPremio personaPremio) {
		return personaPremioRepository.save(personaPremio);	
	}
}
