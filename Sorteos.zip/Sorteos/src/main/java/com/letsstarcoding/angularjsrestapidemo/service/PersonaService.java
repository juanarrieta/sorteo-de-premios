package com.letsstarcoding.angularjsrestapidemo.service;

import java.util.List;

import javax.persistence.EntityExistsException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.repository.PersonaRepository;

@Service
public class PersonaService {

	private PersonaRepository personaRepository;
	
	@Autowired
	public PersonaService(PersonaRepository personaRepository) {
		this.personaRepository = personaRepository;
	}
	
	public Persona save(Persona persona) {
		if(persona.getNumDocumento() != null && personaRepository.exists(persona.getNumDocumento())) {
			throw new EntityExistsException("Ya existe una persona con ese número de documento");
		}
		return personaRepository.save(persona);	
	}
	
	public Persona update(Persona persona) {
		return personaRepository.save(persona);
	}
	
	public List<Persona> findAll(){
		return personaRepository.findAll();
	}
	
	public Persona findOne(Long numDocumento){
		return personaRepository.findOne(numDocumento);
	}
	
	public List<Persona> getPersonaSinPremio(){
		return personaRepository.getPersonaSinPremio();
	}
	
	public void delete(Long numDocumento){
		personaRepository.delete(numDocumento);
	}
}
