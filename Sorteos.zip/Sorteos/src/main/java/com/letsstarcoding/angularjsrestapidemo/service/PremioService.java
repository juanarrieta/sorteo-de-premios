package com.letsstarcoding.angularjsrestapidemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.model.Premio;
import com.letsstarcoding.angularjsrestapidemo.model.Usuario;
import com.letsstarcoding.angularjsrestapidemo.repository.PremioRepository;
import com.letsstarcoding.angularjsrestapidemo.repository.UsuarioRepository;


@Service
public class PremioService {

	private PremioRepository premioRepository;
	
	@Autowired
	public PremioService(PremioRepository premioRepository) {
		this.premioRepository = premioRepository;
	}
	
	public List<Premio> findAll(){
		return premioRepository.findAll();
	}
	
	public Premio findOne(int codigo){
		return premioRepository.findOne(codigo);
	}
	
	public List<Premio> getPremios(){
		return premioRepository.getPremios();
	}
	
	public Premio update(Premio premio) {
		return premioRepository.save(premio);
	}
}
