package com.letsstarcoding.angularjsrestapidemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.letsstarcoding.angularjsrestapidemo.model.Usuario;
import com.letsstarcoding.angularjsrestapidemo.repository.UsuarioRepository;


@Service
public class UsuarioService {

	private UsuarioRepository usuarioRepository;
	
	@Autowired
	public UsuarioService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}
	
	public List<Usuario> findAll(){
		return usuarioRepository.findAll();
	}
	
}
