package dto;

import com.letsstarcoding.angularjsrestapidemo.model.Persona;
import com.letsstarcoding.angularjsrestapidemo.model.Premio;

public class DetallePersonaPremio {

	private Persona persona;
	private Premio premio;
	
	public DetallePersonaPremio() {
		
	}
			
	public DetallePersonaPremio(Persona persona, Premio premio) {
		this.persona = persona;
		this.premio = premio;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	public Premio getPremio() {
		return premio;
	}

	public void setPremio(Premio premio) {
		this.premio = premio;
	}
	
}
