angular.module("crudApp").controller("LoginController", LoginController);

LoginController.inject = [ '$scope', 'Usuario' ];

function LoginController($scope, Usuario) {
	
	$scope.usuarios = Usuario.query();

	$scope.usuario = {};
	
	$scope.login = function() { 
		$scope.usuarios.forEach(function(usu) {
			if(usu['usuario'] == $scope.usuario.usuario && usu['clave'] == $scope.usuario.clave) {
				window.location.href = "http://localhost:8080/personas.html?";
			}
			else {
				alert('Usuario o clave erroneas, intentalo de nuevo');
			}
		});
	}	
}