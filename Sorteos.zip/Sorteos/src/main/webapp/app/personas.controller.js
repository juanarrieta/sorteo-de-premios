angular.module("crudApp").controller("PersonasController", PersonasController);

PersonasController.inject = [ '$scope', 'Persona' ];

function PersonasController($scope, Persona) {
	var ban = 0;
	var val = 0;
	$scope.personas = Persona.query();

	$scope.persona = {};
	
	$scope.buttonText="Guardar";
	
	$scope.guardarPersona = function() {
		val = 0;
		if(ban == 0){
			var datos = JSON.parse(JSON.stringify($scope.personas));
			datos.forEach(person => {
				if(person.numDocumento == $scope.persona.numDocumento){
					  var r = confirm("Ya se encuentra una persona registrada con este numero de documento. desea actualizar los datos?");
					  if (r == false) {
						  val = 1;
						  alert("Por favor cambie el numero de documento para, crear un registro nuevo.");
					  } 
				}
			});
			
		}
		
		if(val != 1){
			Persona.save($scope.persona, function() {
				$scope.personas = Persona.query();
				$scope.persona = {};
				$scope.buttonText="Guardar";
				ban = 0;
			});
		}
	}

	$scope.actualizar = function(persona) {
		$scope.buttonText="Actualizar";
		$scope.persona = persona;
		ban = 1;
	}

	$scope.eliminar = function(persona) {
		persona.$delete({num_documento: persona.num_documento}, function() {
			$scope.personas = Persona.query(function() {
				var datos = JSON.parse(JSON.stringify($scope.personas));
				datos.forEach(person => {
					if(person.numDocumento == persona.numDocumento){
						alert("La persona no puede ser eliminada, ya que posee un premio asociado.");
					}
				});
			});
		});
	}
}