angular.module('crudApp').factory('Persona', Persona);

Persona.$inject = [ '$resource' ];

function Persona($resource) {
	var resourceUrl = 'api/persona/:numDocumento';

	return $resource(resourceUrl, {numDocumento: '@numDocumento'}, {
		'update' : {
			method : 'PUT'
		}
	});
}

