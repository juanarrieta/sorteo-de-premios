angular.module("crudApp").controller("PersonaPremioController", PersonaPremioController);

PersonaPremioController.inject = [ '$scope', 'PersonaPremio' ];

function PersonaPremioController($scope, PersonaPremio) {
	var size = 0;
	$scope.personasPremios = PersonaPremio.query(function() {
		size = 0;
		var datos = JSON.parse(JSON.stringify($scope.personasPremios));
		datos.forEach(person => {
			size++;
		});
	});
	
	$scope.sortearPremios = function() {
		 var r = confirm("Desea iniciar el proceso de asignacion de premios?");
		  if (r == true) {
			  PersonaPremio.save('', function() {
				  var size2 = 0;
				  $scope.personasPremios = PersonaPremio.query(function() {
						var datos = JSON.parse(JSON.stringify($scope.personasPremios));
						datos.forEach(person => {
							size2++;
						});
						if(size2==size)
							alert("No se pudo sortear mas premios. Premios agotados o todas las personas ya tienen un premio asignado.");
						size = size2;
					});
			  });
		  } 
	}
}