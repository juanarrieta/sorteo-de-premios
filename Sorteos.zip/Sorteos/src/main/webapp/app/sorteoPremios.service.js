angular.module('crudApp').factory('PersonaPremio', PersonaPremio);

PersonaPremio.$inject = [ '$resource' ];

function PersonaPremio($resource) {
	var resourceUrl = 'api/persona-premio';

	return $resource(resourceUrl, {}, {
		'update' : {
			method : 'PUT'
		}
	});
}

