angular.module('crudApp').factory('Usuario', Usuario);

Usuario.$inject = [ '$resource' ];

function Usuario($resource) {
	var resourceUrl = 'api/usuario/:id';

	return $resource(resourceUrl, {}, {
		'update' : {
			method : 'PUT'
		}
	});
}